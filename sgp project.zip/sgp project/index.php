<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>SGP || Rakesh</title>
	<link rel="stylesheet" href="bootstrap.min.css"> <!-- Bootstrap -->
	<link rel="stylesheet" type="text/css" href="style2.css"> <!-- Stylesheet -->
	<link rel="shortcut icon" type="image/icon" href="images/favicon.jpg"> <!-- Favicon -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> <!-- Font awesome icons -->
</head>

<body>
	<div class="container">
		<div class="row">
			<!-- arrow animation -->
			<div class="col-md-3 register-left">
				<img src="images/image.png">
			</div>
			<!-- main section -->
			<div class="col-md-7 register-right text-center">
				<h2>SILIGURI GOVERNMENT POLYTECHNIC</h2>
				<hr style="height: 7px;border: none;background: linear-gradient(to right, rgb(20, 20, 20), lightgrey,rgb(20, 20, 20));border-radius: 18px;">
				<img src="images/L_45933.gif"><br>
				<p>Welcome To Online Examination</p>
				<a href="login.php" class="btn btn-custom"> GET START </a><!-- button -->
			</div>
			<!-- ending main section -->
		</div>
	</div>
</body>

</html>